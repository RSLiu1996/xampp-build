@echo off
cd /D %~dp0

killprocess.bat "httpd.exe"

if not exist apache\logs\httpd.pid GOTO exit
del apache\logs\httpd.pid

:exit
