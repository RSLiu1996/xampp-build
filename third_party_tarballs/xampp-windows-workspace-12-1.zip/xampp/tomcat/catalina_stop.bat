@echo off
::::::::::::::::::::::::::::::::::::
::  Check if JAVA_HOME is set
::::::::::::::::::::::::::::::::::::

:: Check if JAVA_HOME is set and not empty
if "%JAVA_HOME%" == "" goto noJavaHome

:: Check if the java.exe binary actually exists in that path
if not exist "%JAVA_HOME%\bin\java.exe" goto badJavaHome

:: If checks pass, proceed to launch Tomcat
echo Using JAVA_HOME: %JAVA_HOME%
goto proceed

:noJavaHome
echo ERROR: The JAVA_HOME environment variable is not defined.
echo Please set it to point to your OpenJDK installation root.
exit /b 1

:badJavaHome
echo ERROR: JAVA_HOME is set incorrectly.
echo Cannot find java.exe at: "%JAVA_HOME%\bin\java.exe"
exit /b 1

:proceed
echo.

set "CURRENT_DIR=%cd%"
set "CATALINA_HOME=%CURRENT_DIR%"

echo.
echo [XAMPP]: Seems fine!
echo [XAMPP]: Using JAVA_HOME : %JAVA_HOME%
echo [XAMPP]: Using CATALINA_HOME : %CATALINA_HOME%
echo.

if %ERRORLEVEL% == 0 (
	del /F/Q logs\catalina.pid
)

"%CATALINA_HOME%\bin\catalina.bat" stop


:END
echo done.
pause
